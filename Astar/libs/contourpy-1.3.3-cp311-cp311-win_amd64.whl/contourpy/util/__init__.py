from __future__ import annotations

from contourpy.util._build_config import build_config

__all__ = ["build_config"]
